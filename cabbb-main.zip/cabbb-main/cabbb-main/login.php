<?php
// Include the database connection file
include('db.php');

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if email and password are provided
    if (isset($_POST['user_email'], $_POST['user_password'])) {
        // Sanitize input values
        $user_email = $_POST['user_email'];
        $user_password = $_POST['user_password'];

        // Query to check if the user exists
        $query = "SELECT * FROM users WHERE user_email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $user_email);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if user exists
        if ($result->num_rows > 0) {
            // Fetch user data
            $user = $result->fetch_assoc();
            
            // Verify the password
            if (password_verify($user_password, $user['user_password'])) {
                // Start a session and store user data in session variables
                session_start();
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['user_name'] = $user['user_name'];
                $_SESSION['user_email'] = $user['user_email'];

                // Redirect to index.html after successful login
                header("Location: index.html");
                exit(); // Stop further execution
            } else {
                echo "Invalid email or password!";
            }
        } else {
            echo "No user found with this email!";
        }

        // Close the prepared statement
        $stmt->close();
    } else {
        echo "Please fill in all fields!";
    }

    // Close the database connection
    $conn->close();
}
?>
