<?php
// Start the session
session_start();

// Include the database connection file
include('db.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "You need to log in first!";
    exit(); // If not logged in, stop further execution
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if the necessary POST variables are set
    if (isset($_POST['pickup_location'], $_POST['dropoff_location'], $_POST['ride_time'], $_POST['car_type'], $_POST['user_id'])) {
        
        // Sanitize input values to prevent SQL injection
        $pickup_location = $_POST['pickup_location'];
        $dropoff_location = $_POST['dropoff_location'];
        $ride_time = $_POST['ride_time'];  // Expecting the format 'YYYY-MM-DD HH:MM:SS'
        $car_type = $_POST['car_type'];
        $user_id = $_POST['user_id']; // Getting the logged-in user ID from the hidden field
        
        // Prepare SQL query to insert the booking data into the database
        $query = "INSERT INTO bookings (pickup_location, dropoff_location, ride_time, car_type, user_id) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssssi", $pickup_location, $dropoff_location, $ride_time, $car_type, $user_id);

        // Execute the query and check if the insertion was successful
        if ($stmt->execute()) {
            echo "Booking successful!";
            // Optionally, redirect to another page or show a confirmation message
            // header("Location: confirmation_page.php"); // Uncomment to redirect
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the prepared statement
        $stmt->close();
    } else {
        echo "All fields are required!";
    }

    // Close the database connection
    $conn->close();
}
?>
